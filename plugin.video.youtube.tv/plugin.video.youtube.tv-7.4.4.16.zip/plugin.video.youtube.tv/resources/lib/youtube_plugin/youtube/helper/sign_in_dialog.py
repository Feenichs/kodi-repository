# -*- coding: utf-8 -*-
"""
    Copyright (C) 2026 plugin.video.youtube.tv (Feenichs)

    SPDX-License-Identifier: GPL-2.0-only
    See LICENSES/GPL-2.0-only for more information.

    Sign-in dialog with a QR code of the sign-in address with the code already
    filled in, so that signing in on a phone only takes a confirmation.
"""

from __future__ import absolute_import, division, unicode_literals

import os
import struct
import zlib

from ...kodion import logging
from ...kodion.compatibility import xbmc, xbmcgui, xbmcvfs
from ...kodion.constants import DATA_PATH
from ...kodion.utils.file_system import make_dirs


ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92

HEADING_LABEL = 1
TEXT_BOX = 11
PROGRESS_BAR = 12
CANCEL_BUTTON = 13


def qr_url(verification_url, user_code):
    """
    Address of the sign-in page with the code filled in: Google's device page
    (also youtube.com/activate, which redirects to it) takes it as user_code.
    """
    if not verification_url.startswith(('http://', 'https://')):
        verification_url = 'https://' + verification_url
    separator = '&' if '?' in verification_url else '?'
    return ''.join((verification_url, separator, 'user_code=', user_code))


def create_qr_image(url, name):
    """Path of a PNG of the QR code of url, or None if it cannot be made"""
    try:
        import pyqrcode
    except ImportError:
        logging.warning('No QR code, script.module.pyqrcode is missing')
        return None
    # Kodi shows no images from its temp folder
    folder = xbmcvfs.translatePath(DATA_PATH + '/sign_in')
    if not make_dirs(folder):
        return None
    path = os.path.join(folder, 'sign_in_{0}.png'.format(name))
    try:
        matrix = pyqrcode.create(url, error='M').code
        with open(path, 'wb') as png_file:
            png_file.write(_png(matrix, scale=10, quiet_zone=2))
    except Exception:
        logging.exception('Creating the QR code failed')
        return None
    return path


def _png(matrix, scale, quiet_zone):
    """
    8-bit greyscale PNG of a QR code matrix (rows of 1 for dark modules).
    Written here, pyqrcode's PNG writer is not needed.
    """
    size = (len(matrix) + 2 * quiet_zone) * scale
    margin = b'\xff' * (quiet_zone * scale)
    blank_row = b'\x00' + b'\xff' * size
    rows = [blank_row] * (quiet_zone * scale)
    for modules in matrix:
        row = b''.join(b'\x00' * scale if module else b'\xff' * scale
                       for module in modules)
        rows.extend([b'\x00' + margin + row + margin] * scale)
    rows.extend([blank_row] * (quiet_zone * scale))

    def chunk(kind, data):
        return b''.join((
            struct.pack('>I', len(data)),
            kind,
            data,
            struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff),
        ))

    return b''.join((
        b'\x89PNG\r\n\x1a\n',
        chunk(b'IHDR', struct.pack('>IIBBBBB', size, size, 8, 0, 0, 0, 0)),
        chunk(b'IDAT', zlib.compress(b''.join(rows), 9)),
        chunk(b'IEND', b''),
    ))


class SignInDialog(xbmcgui.WindowXMLDialog):
    """
    Shown while the sign-in is polled, with the methods of the progress dialog
    of the UI it replaces: set_total, update, is_aborted, and a context manager
    that shows and closes it.
    """

    def __init__(self, *args, **kwargs):
        super(SignInDialog, self).__init__(*args, **kwargs)
        self._heading = ''
        self._text = ''
        self._image = None
        self._total = 100
        self._position = 0
        self._aborted = False

    @classmethod
    def create(cls, context, heading, text, image):
        dialog = cls('script-youtube-signin.xml',
                     context.get_addon_path(),
                     'default',
                     '1080i')
        dialog._heading = heading
        dialog._text = text
        dialog._image = image
        if image:
            dialog.setProperty('qr_image', image)
        return dialog

    def __enter__(self):
        self.show()
        # onInit runs when the window is shown, wait for it
        for _ in range(20):
            if xbmcgui.getCurrentWindowDialogId() >= 13000:
                break
            xbmc.sleep(50)
        return self

    def __exit__(self, *exc_info):
        self.close()
        if self._image:
            try:
                os.remove(self._image)
            except OSError:
                pass

    def onInit(self):
        self.getControl(HEADING_LABEL).setLabel(self._heading)
        self.getControl(TEXT_BOX).setText(self._text)
        self._show_progress()
        self.setFocusId(CANCEL_BUTTON)

    def onClick(self, control_id):
        if control_id == CANCEL_BUTTON:
            self._aborted = True

    def onAction(self, action):
        if action.getId() in (ACTION_NAV_BACK, ACTION_PREVIOUS_MENU):
            self._aborted = True

    def set_total(self, total):
        self._total = max(1, total)

    def update(self, steps=1, **_kwargs):
        self._position += steps
        self._show_progress()

    def is_aborted(self):
        return self._aborted

    def _show_progress(self):
        try:
            self.getControl(PROGRESS_BAR).setPercent(
                min(100, 100 * self._position / self._total)
            )
        except RuntimeError:
            # not shown yet
            pass

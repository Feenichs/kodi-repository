# YouTube für TV (plugin.video.youtube.tv) – TV interface fork of YouTube for Kodi

**Deutsch:** Dieser Fork des [YouTube-Addons für Kodi](https://github.com/anxdpanic/plugin.video.youtube)
bringt eine Oberfläche wie die YouTube-App auf Fire TV und Smart-TVs: Tab-Leiste, Reihen mit
Kacheln, große Vorschau des ausgewählten Videos und Seiten mit 100 Kacheln und Scrollbalken, gemacht für die
Fernbedienung. Alle Funktionen des Originals bleiben erhalten, das klassische Menü ist weiterhin
erreichbar. Dazu kommen einige Fehlerbehebungen.

**English:** This fork of the [YouTube add-on for Kodi](https://github.com/anxdpanic/plugin.video.youtube)
adds an interface like the YouTube app on Fire TV and smart TVs: tab bar, rows of tiles, a large
preview of the selected video and grid pages with 100 tiles and a scrollbar, made for remote controls. All
features of the original are kept, the classic menu is still available. It also includes a
number of bug fixes, see [changelog.txt](changelog.txt).

## Screenshots

![TV interface: tab bar, preview of the selected video and rows of tiles](screenshots/tv-explore.jpg)

![Grid page with tiles for the previous and next page](screenshots/tv-grid.jpg)

![Full context menu of the add-on on every tile](screenshots/tv-context-menu.jpg)

## Installation

**Easiest, with automatic updates:** install the [Feenichs Add-ons repository](https://github.com/Feenichs/kodi-repository)
(add the source `https://feenichs.github.io/kodi-repository/` in Kodi's file manager, install
`repository.feenichs-….zip` from it via *Add-ons → Install from zip file*, with *Unknown sources* enabled), then install the add-on via
*Install from repository → Feenichs Add-ons*.

Or install a single zip:

1. Download the ZIP from the [releases](../../releases) of this repository.
2. In Kodi: *Settings → System → Add-ons* → enable *Unknown sources*.
3. *Add-ons → Install from zip file* → select the ZIP.

The TV interface opens when starting the add-on. It can be disabled in the add-on settings
(*General → TV interface*).

**Since 7.4.4.12** the fork has its own add-on id `plugin.video.youtube.tv` (name "YouTube für TV"), so
it no longer replaces the original `plugin.video.youtube` and both can be installed. Its built-in web
server uses port 50153 by default instead of 50152, so that both can run. Other add-ons that play
YouTube videos (trailers, for example) still call the original add-on.

**Own API keys:** best enter them before signing in. If they are added after signing in, or their access was
revoked (signing out on another device with the same keys revokes it for the whole account), the sign-in has no
token for them and lists of your account would stay empty. The add-on notices this and starts the sign-in once per
Kodi start: confirm the one code it shows, your other devices stay signed in.

**Coming from an older version of the fork:** to keep sign-in, API keys, settings and history, copy
`userdata/addon_data/plugin.video.youtube` to `userdata/addon_data/plugin.video.youtube.tv` **before**
installing, but delete the caches `cache.sqlite` and `requests_cache.sqlite` in its subfolders (their cached
lists contain links with the old id). Then install, enable the add-on under *Add-ons → My add-ons* if needed, update keymaps or
favourites that use the old id and uninstall the old add-on (or keep it for other add-ons).

This is an unofficial fork and not endorsed by Google or the original authors.

---


![](https://github.com/anxdpanic/plugin.video.youtube/raw/master/resources/media/icon.png)

[![Build Status](https://img.shields.io/endpoint.svg?url=https%3A%2F%2Factions-badge.atrox.dev%2Fanxdpanic%2Fplugin.video.youtube%2Fbadge&logo=none)](https://actions-badge.atrox.dev/anxdpanic/plugin.video.youtube/goto)
![License](https://img.shields.io/badge/license-GPL--2.0--only-success.svg)
![Kodi Version](https://img.shields.io/badge/kodi-nexus%2B-success.svg)
![Contributors](https://img.shields.io/github/contributors/anxdpanic/plugin.video.youtube.svg)

## Links

* [YouTube](http://www.youtube.com)
* [Support thread](https://ytaddon.page.link/forum)
* [Wiki](https://github.com/anxdpanic/plugin.video.youtube/wiki)

---

![](https://i.imgur.com/fzPmDDJ.gif)

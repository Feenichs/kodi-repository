"""
    plugin.audio.spotify.tv
    spotify_client.py
    Spotify Web API client for the user's own client id, with a fallback to the
    add-on's shared client id.

    Spotify throttles requests per client id (app). The add-on's client id is
    shared by all its users, so requests are often throttled for many seconds.
    With an own client id, requests are only throttled by the user's own
    usage.

    But apps in development mode, which own client ids are, may only use part
    of the Web API since February 2026, and get some results in a different
    format: https://developer.spotify.com/documentation/web-api/references/changes/february-2026
    So only the requests listed in OWN_CLIENT_METHODS use the own client id,
    and their results are converted to the format of the shared client id.
    Everything else, and every request the own client id may not make, uses
    the shared client id.
"""

import logging
from typing import Any

import requests
import spotipy
import xbmc
from spotipy.util import Retry

import utils
from utils import log_msg

# Requests that apps in development mode may still make, for the user's own
# library and own playlists. Spotify's and other users' playlists only return
# metadata, those are listed with the shared client id. The user's playlists
# are listed with the shared client id too: apps in development mode do not
# get the playlists made by Spotify (mixes, radios, "This Is ..."), not even
# in the total.
OWN_CLIENT_METHODS = {
    "album",
    "album_tracks",
    "artist_albums",
    "current_user_followed_artists",
    "current_user_saved_albums",
    "current_user_saved_tracks",
    "current_user_top_artists",
    "current_user_top_tracks",
    "next",
    "playlist",
    "playlist_items",
}

# Apps in development mode get at most this many albums of an artist per request,
# larger limits fail with "Invalid limit".
OWN_ARTIST_ALBUMS_LIMIT = 10

# Status codes of requests the own client id may not make
FALLBACK_STATUS_CODES = (400, 401, 403, 404, 410)


def _to_shared_format(value: Any) -> Any:
    """Convert a result of the own client id to the format of the shared one"""
    if isinstance(value, list):
        return [_to_shared_format(entry) for entry in value]
    if not isinstance(value, dict):
        return value

    value = {key: _to_shared_format(entry) for key, entry in value.items()}
    kind = value.get("type")
    # playlists: "tracks" was renamed to "items"
    if kind == "playlist" and isinstance(value.get("items"), dict) and "tracks" not in value:
        value["tracks"] = value.pop("items")
    # playlist entries: "track" was renamed to "item", "track" is a boolean now
    if isinstance(value.get("item"), dict) and not isinstance(value.get("track"), dict):
        value["track"] = value.pop("item")
    # removed fields, "genres" is not returned either (not documented)
    if kind in ("track", "album", "artist"):
        value.setdefault("popularity", 0)
    if kind in ("album", "artist"):
        value.setdefault("genres", [])
    if kind == "artist":
        value.setdefault("followers", {"total": 0})
    return value


class FallbackSpotify:
    def __init__(self, own: spotipy.Spotify, shared: spotipy.Spotify):
        self.__own = own
        self.__shared = shared
        # playlists the own client id may not list, e.g. other users' ones,
        # their further pages are listed with the shared client id directly
        self.__shared_playlists = set()

    def __getattr__(self, name: str):
        if name not in OWN_CLIENT_METHODS:
            return getattr(self.__shared, name)

        def call(*args, **kwargs):
            try:
                result = self.__call_own(name, *args, **kwargs)
            except spotipy.SpotifyException as exc:
                if exc.http_status not in FALLBACK_STATUS_CODES:
                    raise
                log_msg(
                    f"'{name}' failed with the own client id ({exc.http_status}),"
                    f" using the shared client id."
                )
                if name in ("playlist", "playlist_items"):
                    self.__shared_playlists.add(self.__playlist_id(*args, **kwargs))
                result = None
            if result is None:
                result = getattr(self.__shared, name)(*args, **kwargs)
            return result

        return call

    def __call_own(self, name: str, *args, **kwargs) -> Any:
        """Result of the own client id, None if the shared client id must be used"""
        if name == "playlist":
            return self.__playlist(*args, **kwargs)
        if name == "playlist_items":
            return self.__playlist_items(*args, **kwargs)
        if name == "artist_albums":
            return self.__artist_albums(*args, **kwargs)
        return _to_shared_format(getattr(self.__own, name)(*args, **kwargs))

    def __artist_albums(self, artist_id, *args, limit=20, offset=0, **kwargs):
        """One page of up to limit albums, from requests of OWN_ARTIST_ALBUMS_LIMIT"""
        result = None
        items = []
        while len(items) < limit:
            page = self.__own.artist_albums(
                artist_id,
                *args,
                limit=min(OWN_ARTIST_ALBUMS_LIMIT, limit - len(items)),
                offset=offset + len(items),
                **kwargs,
            )
            result = result or page
            items += page["items"]
            if not page["items"] or offset + len(items) >= page["total"]:
                break
        result["items"] = items
        result["limit"] = limit
        result["offset"] = offset
        result["next"] = None
        return _to_shared_format(result)

    def __playlist_id(self, playlist_id, *args, **kwargs) -> str:
        return self.__own._get_id("playlist", playlist_id)

    def __playlist(self, playlist_id, fields=None, market=None, **kwargs):
        if self.__playlist_id(playlist_id) in self.__shared_playlists:
            return None
        if fields:
            fields = fields.replace("tracks", "items")
        playlist = _to_shared_format(
            self.__own.playlist(playlist_id, fields=fields, market=market, **kwargs)
        )
        # The tracks are only returned for the user's own playlists.
        # Converted here too, as the type is not returned if fields are selected.
        if "tracks" not in playlist and isinstance(playlist.get("items"), dict):
            playlist["tracks"] = playlist.pop("items")
        if "tracks" not in playlist:
            self.__shared_playlists.add(self.__playlist_id(playlist_id))
            return None
        return playlist

    def __playlist_items(
        self, playlist_id, fields=None, limit=100, offset=0, market=None, **kwargs
    ):
        if self.__playlist_id(playlist_id) in self.__shared_playlists:
            return None
        # the "tracks" endpoint was renamed to "items"
        if fields:
            fields = fields.replace("track", "item")
        return _to_shared_format(
            self.__own._get(
                f"playlists/{self.__own._get_id('playlist', playlist_id)}/items",
                limit=limit,
                offset=offset,
                fields=fields,
                market=market,
                additional_types="track,episode",
            )
        )


class _RateLimitLogHandler(logging.Handler):
    """Shows spotipy's rate limit warnings in the Kodi log, they were not shown"""

    def emit(self, record: logging.LogRecord) -> None:
        if "rate/request limit" in record.getMessage():
            log_msg(record.getMessage(), xbmc.LOGINFO)


if not any(isinstance(handler, _RateLimitLogHandler) for handler in logging.getLogger().handlers):
    logging.getLogger().addHandler(_RateLimitLogHandler(logging.WARNING))


def get_spotify(shared_auth_token: str, patient: bool = True) -> spotipy.Spotify:
    """
    Client for the own client id if there is one, otherwise the shared one.

    A patient client waits when Spotify's rate limit is reached and asks again,
    which can take minutes. An impatient one raises a SpotifyException with
    http_status 429 at once, with Spotify's Retry-After header, for when an
    older copy can be shown instead. Server errors are retried by both.
    """
    shared = _create_client(shared_auth_token, patient)
    own_auth_token = utils.get_own_auth_token()
    if not own_auth_token:
        return shared
    return FallbackSpotify(_create_client(own_auth_token, patient), shared)


def _create_client(auth_token: str, patient: bool) -> spotipy.Spotify:
    client = spotipy.Spotify(auth=auth_token)
    if not patient:
        # urllib3 waits for Retry-After on a 429 even if 429 is not in the
        # status_forcelist, unless respect_retry_after_header is off.
        retry = Retry(
            total=client.retries,
            connect=None,
            read=False,
            allowed_methods=frozenset(["GET", "POST", "PUT", "DELETE"]),
            status=client.status_retries,
            backoff_factor=client.backoff_factor,
            status_forcelist=(500, 502, 503, 504),
            respect_retry_after_header=False,
        )
        adapter = requests.adapters.HTTPAdapter(max_retries=retry)
        client._session.mount("http://", adapter)
        client._session.mount("https://", adapter)
    return client

# -*- coding: utf-8 -*-
"""
Categories of the films for the rows of the home tab and the "Categories" tab. The film list of
MediathekView has no genres: the categories are guessed from the name of the show, the channel,
the duration and words in the title and the beginning of the description.

SPDX-License-Identifier: MIT
"""
import re

FILMS = 'films'
CRIME = 'crime'
DOCS = 'docs'

# feature films and TV films: "Komödie, Deutschland 2019" in the title or the description
_FILM_TEXT = (r'\b(spielfilm|fernsehfilm|kinofilm|komödie|tragikomödie|drama|thriller|western|literaturverfilmung|'
              r'kinderfilm|familienfilm|märchenfilm|animationsfilm|liebesfilm|abenteuerfilm|actionfilm|'
              r'science-fiction-film|horrorfilm|musikfilm|kriminalfilm|historienfilm|filmdrama|krimikomödie|'
              r'psychothriller|roadmovie)\b[^.+]{0,60}\b(19[2-9]\d|20[0-3]\d)\b')
_FILM_SHOWS = (r'^(filme|kino - filme|spielfilm|fernsehfilm|das kleine fernsehspiel|film$|filme in der ard|kinofilme|'
               r'spielfilme|filmdebüt)')
# shows that are no films although they are long or mention one, and crime series (they have a category of their own)
_NOT_FILM_SHOWS = (r'(magazin|talk|lanz|maischberger|illner|miosga|hart aber fair|sport|fußball|landesschau|'
                   r'kaffee oder tee|volle kanne|hier und heute|aktuell|nachrichten|tagesschau|heute|journal|phoenix|'
                   r'parlament|nachtcafé|literaturclub|kulturzeit|ttt|druckfrisch|filmgrößen|trailer|tatort|polizeiruf|'
                   r'krimi|soko|wolfsland|kommissar|staffel)')
_CRIME_SHOWS = (r'^(tatort|polizeiruf|soko|der alte|ein starkes team|der kommissar|kommissar|wilsberg|der staatsanwalt|'
                r'die rosenheim-cops|hubert|rentnercops|großstadtrevier|morden im norden|notruf hafenkante|'
                r'nord bei nordwest|der usedom-krimi|der bozen-krimi|der kroatien-krimi|der irland-krimi|friesland|'
                r'wolfsland|mankells wallander|kommissar wallander|kommissar wisting|kommissar van der valk|'
                r'inspector barnaby|death in paradise|helen dorn|kommissarin|die chefin|stralsund|marie brand|'
                r'nord nord mord|der zürich-krimi|der barcelona-krimi|der masuren-krimi|der kriminalist|'
                r'letzte spur berlin|krimi und thriller|krimis?\b|.*krimi$)')

# (key, string id, minimum minutes, channels, show pattern, pattern of title and description, excluded shows)
CATEGORIES = (
    (FILMS, 30623, 70, (), _FILM_SHOWS, _FILM_TEXT, _NOT_FILM_SHOWS),
    (CRIME, 30625, 40, (), _CRIME_SHOWS, r'^(krimi|kriminalfilm|krimikomödie|thriller)\b', r'(magazin|talk|trailer)'),
    (DOCS, 30624, 25, (), r'(doku|dokumentation|reportage|dokumentarfilm|terra x|die story|story$|exclusiv im ersten|'
                          r'panorama|die nordreportage|37 grad|expeditionen|universum|re:|360° geo)',
     r'^(dokumentation|dokumentarfilm|doku|reportage)\b', r'(trailer|wetter)'),
    ('knowledge', 30704, 10, (), r'^(terra x|quarks|nano|planet wissen|w wie wissen|leschs kosmos|abenteuer forschung|'
                                 r'gut zu wissen|odysso|xenius|scobel|alpha-centauri|alpha-doku|maithink|planet e|plan b|'
                                 r'wissenschaft|wissen)', None, None),
    ('kids', 30705, 5, ('KiKA', 'ZDF-tivi'), r'^(die sendung mit der maus|die maus|unser sandmännchen|sandmännchen|'
                                             r'löwenzahn|checker|logo!|pur\+|wissen macht ah|shaun das schaf|'
                                             r'die pfefferkörner|tigerenten club|siebenstein|feuerwehrmann sam|peppa|'
                                             r'bibi|benjamin blümchen|pippi|pumuckl|der kleine drache|'
                                             r'die sendung mit dem elefanten)', None, None),
    ('satire', 30706, 15, (), r'(heute-show|extra 3|magazin royale|die anstalt|kebekus|kabarett|comedy|satire|'
                              r'mitternachtsspitzen|nuhr|ladies night|olaf schubert|mann, sieber|reschke fernsehen|'
                              r'stratmanns|spätschicht|schlachthof|pufpaff|happy hour|ringlstetter|quatsch|night wash|'
                              r'hirschhausen)', None, r'(nachrichten)'),
    ('talk', 30707, 30, (), r'^(markus lanz|maischberger|hart aber fair|caren miosga|maybrit illner|3nach9|ndr talk show|'
                            r'kölner treff|riverboat|nachtcafé|tietjen und|deutschland talkt|menschen bei maischberger|'
                            r'talk|presseclub|internationaler frühschoppen|unter den linden|phoenix runde|'
                            r'studio friedman|anne will)', None, None),
    ('music', 30708, 25, (), r'(arte concert|rockpalast|konzert|jazz|klassik(?!er)|\boper\b|philharmoni|musikantenstadl|'
                             r'schlager|zdf@bauhaus|inas nacht|musik$|^musik|festival|the voice|unser lied)',
     r'^(konzert|live:)', r'(biathlon|sport)'),
    ('sport', 30709, 10, (), r'(sportschau|sportstudio|\bsport\b|sport$|^sport|fußball|bundesliga|formel 1|wintersport|'
                             r'biathlon|\bski\b|handball|basketball|tennis|olympi|dfb-team|\bwm\b|\bem\b)',
     None, r'(sport-clip|trailer)'),
)
# the rows of the home tab built from categories
HOME_CATEGORIES = (FILMS, CRIME, DOCS)
# films of the last days the categories are made of
DAYS = 30
# the shortest category
MIN_DURATION = min(c[2] for c in CATEGORIES) * 60

# episodes of series are no films: "(S01/E13)", "Folge 4:"
_EPISODE = re.compile(r'(\(S\d+/E\d+\)|\bFolge \d+\b)', re.I)


def _compile(pattern):
    return re.compile(pattern) if pattern else None


_COMPILED = tuple((key, string_id, minutes * 60, set(c.lower() for c in channels), _compile(show), _compile(text),
                   _compile(exclude))
                  for key, string_id, minutes, channels, show, text, exclude in CATEGORIES)


def classify(title, show, channel, description, duration):
    """ The keys of the categories of a film """
    show = (show or '').lower()
    channel = (channel or '').lower()
    title = title or ''
    duration = duration or 0
    text = (title + ' ' + (description or '')[:300]).lower()
    episode = _EPISODE.search(title)
    keys = []
    for key, _, min_duration, channels, show_re, text_re, exclude_re in _COMPILED:
        if duration < min_duration or (key == FILMS and episode):
            continue
        if exclude_re and exclude_re.search(show):
            continue
        if channel in channels or (show_re and show_re.search(show)) or (text_re and text_re.search(text)):
            keys.append(key)
    return keys

# -*- coding: utf-8 -*-
"""
The service module

Copyright 2017-2018, Leo Moll and Dominik Schlösser
SPDX-License-Identifier: MIT
"""

# -- Imports ------------------------------------------------
from __future__ import unicode_literals
import time

from resources.lib.kodi.kodiaddon import KodiService
from resources.lib.monitorKodi import MonitorKodi

from resources.lib.notifierKodi import NotifierKodi
from resources.lib.updater import MediathekViewUpdater
import resources.lib.appContext as appContext

# -- Classes ------------------------------------------------


class MediathekViewService(KodiService):
    """ The main service class """

    def __init__(self):
        super(MediathekViewService, self).__init__()
        # self.set_topic('Service')
        self.logger = appContext.MVLOGGER.get_new_logger('MediathekViewService')
        self.settings = appContext.MVSETTINGS
        self.notifier = appContext.MVNOTIFIER
        self.monitor = MonitorKodi()
        appContext.initMonitor(self.monitor)
        self.updater = MediathekViewUpdater()
        self._lastDatabaseType = self.settings.getDatabaseType()
        self._imagesRetry = 0

    def __del__(self):
        self.logger = None
        self.settings = None
        self.notifier = None
        self.monitor = None
        self.updater = None

    def init(self):
        """ Initialisation of the service """
        self.logger.debug('init')

    def run(self):
        """ Execution of the service """
        self.logger.debug('Service Startup...')
        # Wait for Kodi to retrieve network
        self.monitor.wait_for_abort(self.settings.getDelayStartupSec())
        # error counter to slow down
        self.errorCount = 0
        self._ensureIndexes()
        #
        while not self.monitor.abort_requested():
            # slow down in case of errors (+1 because 0 is unlimited!)
            delayInSec = (self.errorCount * 60) + 1
            self.monitor.wait_for_abort(delayInSec)
            if delayInSec > 1:
                self.logger.warn('Delayed service agent by {} sec due to error count {}', delayInSec, self.errorCount)
            #
            self.updater = MediathekViewUpdater()
            self.updater.init()
            #
            try:
                # we need this for database change and update variable cache
                if self._lastDatabaseType != self.settings.getDatabaseType():
                    self.logger.debug('database change from {} to {}', self._lastDatabaseType, self.settings.getDatabaseType())
                    self._lastDatabaseType = self.settings.getDatabaseType()
                    self.updater.database.get_status()
                if self.settings.getDatabaseUpateMode() > 0:
                    self.updater.doUpdate()
                self.errorCount = 0
            except Exception as err:
                self.logger.error('MediathekViewUpdater {}', err)
                self.updater.exit()
                self.settings.setDatabaseStatus('UNINIT');
                self.errorCount = self.errorCount + 1
            #
            self.updater.exit()
            self._refreshImages()
            # Sleep/wait for abort for 60 seconds
            if self.monitor.wait_for_abort(appContext.MVSETTINGS.getUpdateCheckIntervel()):
                # Abort was requested while waiting. We should exit
                break
        self.logger.info('Shutting down Service')

    def _refreshImages(self):
        """ Index of the websites of the films for the preview images of the TV interface """
        if self._imagesRetry > time.time() or appContext.ADDONCLASS.getSetting('tvimages') == 'false':
            return
        try:
            from resources.lib import images
            images.ImageStore(self.settings.getDatapath()).refresh(self.monitor.abort_requested, self.logger)
        # pylint: disable=broad-except
        except Exception as err:
            self.logger.error('Index of the websites failed: {}', err)
            # e.g. offline: try again later instead of every check interval
            self._imagesRetry = time.time() + 900

    def _ensureIndexes(self):
        """ Databases of older versions lack the indexes of the views """
        try:
            self.updater.init()
            if self.updater.database is not None and self.settings.getDatabaseStatus() == 'IDLE':
                self.updater.database.ensureIndexes()
        # pylint: disable=broad-except
        except Exception as err:
            self.logger.error('ensureIndexes {}', err)
        self.updater.exit()

    def exit(self):
        """ Shutdown of the service """
        self.logger.info('Exit Service')
        self.updater.exit()

